Shader "Borzblade/Retro Render Toolkit/PSX PS2 Terrain Lit"
{
    Properties
    {
        [HideInInspector] [ToggleUI] _EnableHeightBlend("EnableHeightBlend", Float) = 0.0
        _HeightTransition("Height Transition", Range(0, 1.0)) = 0.0
        // Layer count is passed down to guide height-blend enable/disable, due
        // to the fact that heigh-based blend will be broken with multipass.
        [HideInInspector] [PerRendererData] _NumLayersCount ("Total Layer Count", Float) = 1.0

        // set by terrain engine
        [HideInInspector] _Control("Control (RGBA)", 2D) = "red" {}
        [HideInInspector] _Splat3("Layer 3 (A)", 2D) = "grey" {}
        [HideInInspector] _Splat2("Layer 2 (B)", 2D) = "grey" {}
        [HideInInspector] _Splat1("Layer 1 (G)", 2D) = "grey" {}
        [HideInInspector] _Splat0("Layer 0 (R)", 2D) = "grey" {}
        [HideInInspector] _Normal3("Normal 3 (A)", 2D) = "bump" {}
        [HideInInspector] _Normal2("Normal 2 (B)", 2D) = "bump" {}
        [HideInInspector] _Normal1("Normal 1 (G)", 2D) = "bump" {}
        [HideInInspector] _Normal0("Normal 0 (R)", 2D) = "bump" {}
        [HideInInspector] _Mask3("Mask 3 (A)", 2D) = "grey" {}
        [HideInInspector] _Mask2("Mask 2 (B)", 2D) = "grey" {}
        [HideInInspector] _Mask1("Mask 1 (G)", 2D) = "grey" {}
        [HideInInspector] _Mask0("Mask 0 (R)", 2D) = "grey" {}
        [HideInInspector][Gamma] _Metallic0("Metallic 0", Range(0.0, 1.0)) = 0.0
        [HideInInspector][Gamma] _Metallic1("Metallic 1", Range(0.0, 1.0)) = 0.0
        [HideInInspector][Gamma] _Metallic2("Metallic 2", Range(0.0, 1.0)) = 0.0
        [HideInInspector][Gamma] _Metallic3("Metallic 3", Range(0.0, 1.0)) = 0.0
        [HideInInspector] _Smoothness0("Smoothness 0", Range(0.0, 1.0)) = 0.5
        [HideInInspector] _Smoothness1("Smoothness 1", Range(0.0, 1.0)) = 0.5
        [HideInInspector] _Smoothness2("Smoothness 2", Range(0.0, 1.0)) = 0.5
        [HideInInspector] _Smoothness3("Smoothness 3", Range(0.0, 1.0)) = 0.5

        // used in fallback on old cards & base map
        [HideInInspector] _MainTex("BaseMap (RGB)", 2D) = "grey" {}
        [HideInInspector] _BaseColor("Main Color", Color) = (1,1,1,1)

        [HideInInspector] _TerrainHolesTexture("Holes Map (RGB)", 2D) = "white" {}

        [ToggleUI] _EnableInstancedPerPixelNormal("Enable Instanced per-pixel normal", Float) = 1.0

        [Toggle(_TERRAIN_RETRO_VERTEX_SNAP)] _TerrainRetroVertexSnapEnabled("Vertex Snap Enabled", Float) = 1
        _TerrainRetroVertexSnapStrength("Vertex Snap Strength", Range(0, 1)) = 0.25
        _TerrainRetroVertexSnapResolution("Vertex Snap Resolution", Range(24, 1024)) = 300
        _TerrainRetroVertexSnapDistanceFade("Vertex Snap Distance Fade", Range(0, 1)) = 0.4
        _TerrainRetroVertexSnapFadeStart("Snap Fade Start", Float) = 10
        _TerrainRetroVertexSnapFadeEnd("Snap Fade End", Float) = 90
        _TerrainRetroVertexSnapSeamReduction("Snap Seam Reduction", Range(0, 1)) = 0.1
        [Enum(Screen,0,View World,1)] _TerrainRetroVertexSnapSpace("Vertex Snap Space", Float) = 0

        [Toggle(_TERRAIN_RETRO_VERTEX_WOBBLE)] _TerrainRetroVertexWobbleEnabled("Vertex Wobble Enabled", Float) = 0
        _TerrainRetroVertexWobbleStrength("Vertex Wobble Strength", Range(0, 1)) = 0.08
        _TerrainRetroVertexWobbleSpeed("Vertex Wobble Speed", Range(0, 12)) = 1.5
        _TerrainRetroVertexWobbleScale("Vertex Wobble Scale", Range(0.1, 24)) = 3

        [Toggle(_TERRAIN_RETRO_UV_PIXEL)] _TerrainRetroUvPixelEnabled("UV Pixelation Enabled", Float) = 1
        _TerrainRetroUvPixelStrength("UV Pixelation Strength", Range(0, 1)) = 0.18
        _TerrainRetroUvPixelResolution("UV Pixelation Resolution", Range(16, 2048)) = 384
        _TerrainRetroUvPixelAspect("UV Pixelation Aspect", Range(0.25, 4)) = 1

        [Toggle(_TERRAIN_RETRO_POSTERIZE)] _TerrainRetroPosterizeEnabled("Posterize Enabled", Float) = 1
        _TerrainRetroPosterizeSteps("Posterize Steps", Range(2, 64)) = 24
        _TerrainRetroPaletteStrength("Palette Strength", Range(0, 1)) = 0.14
        _TerrainRetroPaletteSteps("Palette Steps", Range(2, 64)) = 32

        [Toggle(_TERRAIN_RETRO_DITHER)] _TerrainRetroDitherEnabled("Ordered Dither Enabled", Float) = 1
        _TerrainRetroDitherStrength("Dither Strength", Range(0, 1)) = 0.08
        _TerrainRetroDitherScale("Dither Scale", Range(0.25, 8)) = 1

        [Toggle(_TERRAIN_RETRO_LIGHT_BANDS)] _TerrainRetroLightBandsEnabled("Light Banding Enabled", Float) = 0
        _TerrainRetroLightBands("Light Bands", Range(1, 12)) = 6
        _TerrainRetroBandStrength("Band Strength", Range(0, 1)) = 0.2

        [Toggle(_TERRAIN_RETRO_FOG)] _TerrainRetroFogEnabled("Retro Fog Enabled", Float) = 0
        _TerrainRetroFogColor("Retro Fog Color", Color) = (0.42, 0.46, 0.50, 1)
        _TerrainRetroFogStart("Retro Fog Start", Float) = 18
        _TerrainRetroFogEnd("Retro Fog End", Float) = 70
        _TerrainRetroFogDensity("Retro Fog Density", Range(0.001, 1)) = 0.035
        _TerrainRetroFogSteps("Retro Fog Steps", Range(0, 16)) = 6
        [Enum(Linear,0,Exponential,1)] _TerrainRetroFogBlendMode("Retro Fog Blend Mode", Float) = 0
    }

    HLSLINCLUDE

    #pragma multi_compile_fragment __ _ALPHATEST_ON
    #pragma shader_feature_local _TERRAIN_RETRO_VERTEX_SNAP
    #pragma shader_feature_local _TERRAIN_RETRO_VERTEX_WOBBLE
    #pragma shader_feature_local _TERRAIN_RETRO_UV_PIXEL
    #pragma shader_feature_local_fragment _TERRAIN_RETRO_POSTERIZE
    #pragma shader_feature_local_fragment _TERRAIN_RETRO_DITHER
    #pragma shader_feature_local_fragment _TERRAIN_RETRO_LIGHT_BANDS
    #pragma shader_feature_local_fragment _TERRAIN_RETRO_FOG

    ENDHLSL

    SubShader
    {
        Tags { "Queue" = "Geometry-100" "RenderType" = "Opaque" "RenderPipeline" = "UniversalPipeline" "UniversalMaterialType" = "Lit" "IgnoreProjector" = "False" "TerrainCompatible" = "True"}

        Pass
        {
            Name "ForwardLit"
            Tags { "LightMode" = "UniversalForward" }
            HLSLPROGRAM
            #pragma target 3.0

            #pragma vertex SplatmapVert
            #pragma fragment SplatmapFragment

            #define _METALLICSPECGLOSSMAP 1
            #define _SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A 1

            // -------------------------------------
            // Universal Pipeline keywords
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            #pragma multi_compile _ _ADDITIONAL_LIGHTS_VERTEX _ADDITIONAL_LIGHTS
            #pragma multi_compile _ LIGHTMAP_SHADOW_MIXING
            #pragma multi_compile _ SHADOWS_SHADOWMASK
            #pragma multi_compile _ _LIGHT_LAYERS
            #pragma multi_compile _ _CLUSTER_LIGHT_LOOP
            #pragma multi_compile _ EVALUATE_SH_MIXED EVALUATE_SH_VERTEX
            #pragma multi_compile_fragment _ _ADDITIONAL_LIGHT_SHADOWS
            #pragma multi_compile_fragment _ _REFLECTION_PROBE_BLENDING
            #pragma multi_compile_fragment _ _REFLECTION_PROBE_ATLAS
            #pragma multi_compile_fragment _ _SHADOWS_SOFT _SHADOWS_SOFT_LOW _SHADOWS_SOFT_MEDIUM _SHADOWS_SOFT_HIGH
            #pragma multi_compile_fragment _ _SCREEN_SPACE_OCCLUSION
            #pragma multi_compile_fragment _ _SCREEN_SPACE_IRRADIANCE
            #pragma multi_compile_fragment _ _DBUFFER_MRT1 _DBUFFER_MRT2 _DBUFFER_MRT3
            #pragma multi_compile_fragment _ _LIGHT_COOKIES
            #include_with_pragmas "Packages/com.unity.render-pipelines.core/ShaderLibrary/FoveatedRenderingKeywords.hlsl"
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/Fog.hlsl"
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"

            // -------------------------------------
            // Unity defined keywords
            #pragma multi_compile _ DIRLIGHTMAP_COMBINED
            #pragma multi_compile _ LIGHTMAP_ON
            #pragma multi_compile_fragment _ LIGHTMAP_BICUBIC_SAMPLING
            #pragma multi_compile_fragment _ REFLECTION_PROBE_ROTATION
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ProbeVolumeVariants.hlsl"
            #pragma multi_compile _ DYNAMICLIGHTMAP_ON
            #pragma multi_compile_fragment _ DEBUG_DISPLAY
            #pragma multi_compile_instancing
            #pragma instancing_options assumeuniformscaling nomatrices nolightprobe nolightmap

            #pragma shader_feature_local_fragment _TERRAIN_BLEND_HEIGHT
            #pragma shader_feature_local _NORMALMAP
            #pragma shader_feature_local_fragment _MASKMAP
            // Sample normal in pixel shader when doing instancing
            #pragma shader_feature_local _TERRAIN_INSTANCED_PERPIXEL_NORMAL

            #if USE_DYNAMIC_BRANCH_FOG_KEYWORD && SHADER_API_VULKAN && SHADER_API_MOBILE
            #define SKIP_SHADOWS_LIGHT_INDEX_CHECK 1
            #endif

            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainLitInput.hlsl"
            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainRetroMacros.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/Shaders/Terrain/TerrainLitPasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "ShadowCaster"
            Tags{"LightMode" = "ShadowCaster"}

            ZWrite On
            ColorMask 0

            HLSLPROGRAM
            #pragma target 2.0

            #pragma vertex ShadowPassVertex
            #pragma fragment ShadowPassFragment

            #pragma multi_compile_instancing
            #pragma instancing_options assumeuniformscaling nomatrices nolightprobe nolightmap

            // -------------------------------------
            // Universal Pipeline keywords

            // This is used during shadow map generation to differentiate between directional and punctual light shadows, as they use different formulas to apply Normal Bias
            #pragma multi_compile_vertex _ _CASTING_PUNCTUAL_LIGHT_SHADOW

            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainLitInput.hlsl"
            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainRetroMacros.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/Shaders/Terrain/TerrainLitPasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "GBuffer"
            Tags{"LightMode" = "UniversalGBuffer"}

            HLSLPROGRAM
            #pragma target 4.5

            // Deferred Rendering Path does not support the OpenGL-based graphics API:
            // Desktop OpenGL, OpenGL ES 3.0, WebGL 2.0.
            #pragma exclude_renderers gles3 glcore

            #pragma vertex SplatmapVert
            #pragma fragment SplatmapFragment

            #define _METALLICSPECGLOSSMAP 1
            #define _SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A 1

            // -------------------------------------
            // Universal Pipeline keywords
            #pragma multi_compile _ _MAIN_LIGHT_SHADOWS _MAIN_LIGHT_SHADOWS_CASCADE _MAIN_LIGHT_SHADOWS_SCREEN
            //#pragma multi_compile _ _ADDITIONAL_LIGHTS_VERTEX _ADDITIONAL_LIGHTS
            //#pragma multi_compile _ _ADDITIONAL_LIGHT_SHADOWS
            #pragma multi_compile_fragment _ _REFLECTION_PROBE_BLENDING
            #pragma multi_compile_fragment _ _SHADOWS_SOFT _SHADOWS_SOFT_LOW _SHADOWS_SOFT_MEDIUM _SHADOWS_SOFT_HIGH
            #pragma multi_compile_fragment _ _DBUFFER_MRT1 _DBUFFER_MRT2 _DBUFFER_MRT3
            #pragma multi_compile_fragment _ _RENDER_PASS_ENABLED
            #pragma multi_compile _ _CLUSTER_LIGHT_LOOP
            #pragma multi_compile _ EVALUATE_SH_MIXED EVALUATE_SH_VERTEX
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"

            // -------------------------------------
            // Unity defined keywords
            #pragma multi_compile _ LIGHTMAP_SHADOW_MIXING
            #pragma multi_compile _ SHADOWS_SHADOWMASK
            #pragma multi_compile _ DIRLIGHTMAP_COMBINED
            #pragma multi_compile_fragment _ _SCREEN_SPACE_IRRADIANCE
            #pragma multi_compile _ LIGHTMAP_ON
            #pragma multi_compile_fragment _ LIGHTMAP_BICUBIC_SAMPLING
            #pragma multi_compile_fragment _ REFLECTION_PROBE_ROTATION
            #pragma multi_compile _ DYNAMICLIGHTMAP_ON
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/ProbeVolumeVariants.hlsl"
            #pragma multi_compile_fragment _ _GBUFFER_NORMALS_OCT

            #pragma multi_compile_instancing
            #pragma instancing_options assumeuniformscaling nomatrices nolightprobe nolightmap

            #pragma shader_feature_local _TERRAIN_BLEND_HEIGHT
            #pragma shader_feature_local _NORMALMAP
            #pragma shader_feature_local _MASKMAP
            // Sample normal in pixel shader when doing instancing
            #pragma shader_feature_local _TERRAIN_INSTANCED_PERPIXEL_NORMAL
            #define TERRAIN_GBUFFER 1

            #if USE_DYNAMIC_BRANCH_FOG_KEYWORD && SHADER_API_VULKAN && SHADER_API_MOBILE
            #define SKIP_SHADOWS_LIGHT_INDEX_CHECK 1
            #endif

            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainLitInput.hlsl"
            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainRetroMacros.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/Shaders/Terrain/TerrainLitPasses.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "DepthOnly"
            Tags{"LightMode" = "DepthOnly"}

            ZWrite On
            ColorMask R

            HLSLPROGRAM
            #pragma target 2.0

            #pragma vertex DepthOnlyVertex
            #pragma fragment DepthOnlyFragment

            #pragma multi_compile_instancing
            #pragma instancing_options assumeuniformscaling nomatrices nolightprobe nolightmap

            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainLitInput.hlsl"
            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainRetroMacros.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/Shaders/Terrain/TerrainLitPasses.hlsl"
            ENDHLSL
        }

        // This pass is used when drawing to a _CameraNormalsTexture texture
        Pass
        {
            Name "DepthNormals"
            Tags{"LightMode" = "DepthNormals"}

            ZWrite On

            HLSLPROGRAM
            #pragma target 2.0
            #pragma vertex DepthNormalOnlyVertex
            #pragma fragment DepthNormalOnlyFragment

            #pragma shader_feature_local _NORMALMAP
            #include_with_pragmas "Packages/com.unity.render-pipelines.universal/ShaderLibrary/RenderingLayers.hlsl"

            #pragma multi_compile_instancing
            #pragma instancing_options assumeuniformscaling nomatrices nolightprobe nolightmap

            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainLitInput.hlsl"
            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainRetroMacros.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/Shaders/Terrain/TerrainLitDepthNormalsPass.hlsl"
            ENDHLSL
        }

        Pass
        {
            Name "SceneSelectionPass"
            Tags { "LightMode" = "SceneSelectionPass" }

            HLSLPROGRAM
            #pragma target 2.0

            #pragma vertex DepthOnlyVertex
            #pragma fragment DepthOnlyFragment

            #pragma multi_compile_instancing
            #pragma instancing_options assumeuniformscaling nomatrices nolightprobe nolightmap

            #define SCENESELECTIONPASS
            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainLitInput.hlsl"
            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainRetroMacros.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/Shaders/Terrain/TerrainLitPasses.hlsl"
            ENDHLSL
        }

        // This pass it not used during regular rendering, only for lightmap baking.
        Pass
        {
            Name "Meta"
            Tags{"LightMode" = "Meta"}

            Cull Off

            HLSLPROGRAM
            #pragma vertex TerrainVertexMeta
            #pragma fragment TerrainFragmentMeta

            #pragma multi_compile_instancing
            #pragma instancing_options assumeuniformscaling nomatrices nolightprobe nolightmap
            #pragma shader_feature EDITOR_VISUALIZATION
            #define _METALLICSPECGLOSSMAP 1
            #define _SMOOTHNESS_TEXTURE_ALBEDO_CHANNEL_A 1

            #include "Assets/Borzblade/PSX/RetroRenderToolkit/Shaders/Terrain/PSXPS2TerrainLitInput.hlsl"
            #include "Packages/com.unity.render-pipelines.universal/Shaders/Terrain/TerrainLitMetaPass.hlsl"

            ENDHLSL
        }

        UsePass "Hidden/Nature/Terrain/Utilities/PICKING"
    }
    // Unity Terrain asks this dependency shader for layers beyond the first four.
    // Use URP's built-in add pass here because Unity can import it reliably before project-local hidden shaders.
    Dependency "AddPassShader" = "Hidden/Universal Render Pipeline/Terrain/Lit (Add Pass)"
    // Keep the distant basemap fallback on the stock URP terrain shader; the visible base terrain pass carries the retro treatment.
    Dependency "BaseMapShader" = "Hidden/Universal Render Pipeline/Terrain/Lit (Base Pass)"
    Dependency "BaseMapGenShader" = "Hidden/Universal Render Pipeline/Terrain/Lit (Basemap Gen)"

    CustomEditor "Borzblade.RetroRenderToolkit.Editor.PSXPS2TerrainShaderGUI"

    Fallback "Hidden/Universal Render Pipeline/FallbackError"
}
